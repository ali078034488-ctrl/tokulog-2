(() => {
  if (window.__TOKU_CALL_LOG_HOOK_INSTALLED__) return;
  window.__TOKU_CALL_LOG_HOOK_INSTALLED__ = true;

  const PHONE_SELECTOR = 'p[data-testid="Base-Dialer-Keypad-Number-Flex-Text-0"]';
  const WRAPUP_SELECTOR = [
    '.toku-select-selection-item[title="Wrap Up"]',
    '.toku-select-selector .toku-select-selection-item[title="Wrap Up"]',
    '[aria-controls="toku-omnichannel--agent-status-dropdown_list"] .toku-select-selection-item[title="Wrap Up"]',
  ].join(',');

  const CONFIRM_SELECTOR = [
    '#toku-omnichannel--wrapUp-confirmButton',
    '[data-testid="toku-omnichannel--wrapUp-confirmButton"]',
  ].join(',');

  const COUNTDOWN_SELECTOR = [
    '[data-testid="Base-Dialer-Wrapup-WrapUpCountdown-Flex-CircularProgress-CircularProgressLabel-Text-2"]',
    '[data-testid="Base-Dialer-Wrapup-WrapUpCountdown-Flex-CircularProgress-CircularProgressLabel-Text-Text-3"]',
  ].join(',');

  const post = (type, payload = {}) => {
    try {
      const target = window.top && window.top !== window ? window.top : window;
      target.postMessage({ __TOKU_CALL_LOG__: true, type, payload }, "*");
    } catch {
      window.postMessage({ __TOKU_CALL_LOG__: true, type, payload }, "*");
    }
  };

  const cleanPhone = (value) => (value || "").toString().replace(/[^\d+]/g, "").trim();
  const normalizePhoneKey = (value) => (value || "").toString().replace(/\D/g, "").trim();
  let lastPhone = "";
  let lastWrapUpVisible = false;
  let lastWrapUpPhoneKey = "";
  let lastWrapUpEmittedPhoneKey = "";
  let lastConfirmVisible = false;
  let lastConfirmPhoneKey = "";
  let lastConfirmEmittedPhoneKey = "";
  let lastCountdownVisible = false;
  let lastCountdownPhoneKey = "";
  let lastCountdownEmittedPhoneKey = "";
  let lastConfirmClickedPhoneKey = "";

  const readPhone = () => {
    const el = document.querySelector(PHONE_SELECTOR);
    if (!el) return "";
    return cleanPhone(el.textContent || el.innerText || "");
  };

  const emitPhone = () => {
    const phone = readPhone();
    if (phone && phone !== lastPhone) {
      lastPhone = phone;
      post("PHONE", { phone });
    }
  };

  const isVisible = (el) => {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (!style || style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
    const rects = el.getClientRects();
    return !!(el.offsetWidth || el.offsetHeight || rects.length);
  };

  const emitWrapUpVisible = () => {
    const phone = readPhone();
    if (!phone) {
      lastWrapUpVisible = false;
      return;
    }

    const candidates = Array.from(document.querySelectorAll(WRAPUP_SELECTOR));
    const el = candidates.find(isVisible);
    const text = (el && (el.textContent || el.innerText || el.value || '') || '').toString().trim();
    const title = String(el && el.getAttribute && el.getAttribute('title') || '');
    const looksLikeWrapUp = !!el && (/^\s*wrap\s*up\s*$/i.test(text) || /wrap\s*up/i.test(text) || /wrap\s*up/i.test(title));
    const phoneKey = normalizePhoneKey(phone);

    if (!phoneKey) {
      lastWrapUpVisible = false;
      return;
    }

    if (!looksLikeWrapUp) {
      lastWrapUpVisible = false;
      lastWrapUpPhoneKey = phoneKey;
      return;
    }

    const justAppeared = !lastWrapUpVisible || lastWrapUpPhoneKey !== phoneKey;
    lastWrapUpVisible = true;
    lastWrapUpPhoneKey = phoneKey;

    if (!justAppeared) return;
    if (lastWrapUpEmittedPhoneKey === phoneKey) return;

    lastWrapUpEmittedPhoneKey = phoneKey;
    post("WRAPUP_VISIBLE", { phone, at: Date.now(), text });
  };


  const emitConfirmVisible = () => {
    const phone = readPhone();
    if (!phone) {
      lastConfirmVisible = false;
      return;
    }

    const candidates = Array.from(document.querySelectorAll(CONFIRM_SELECTOR));
    const el = candidates.find(isVisible);
    const text = (el && (el.textContent || el.innerText || el.value || '') || '').toString().trim();
    const title = String(el && el.getAttribute && el.getAttribute('title') || '');
    const looksLikeConfirm = !!el && (/^\s*confirm\s*$/i.test(text) || /confirm/i.test(text) || /confirm/i.test(title));
    const phoneKey = normalizePhoneKey(phone);

    if (!phoneKey) {
      lastConfirmVisible = false;
      return;
    }

    if (!looksLikeConfirm) {
      lastConfirmVisible = false;
      lastConfirmPhoneKey = phoneKey;
      return;
    }

    const justAppeared = !lastConfirmVisible || lastConfirmPhoneKey !== phoneKey;
    lastConfirmVisible = true;
    lastConfirmPhoneKey = phoneKey;

    if (!justAppeared) return;
    if (lastConfirmEmittedPhoneKey === phoneKey) return;

    lastConfirmEmittedPhoneKey = phoneKey;
    post("CONFIRM_VISIBLE", { phone, at: Date.now(), text });
  };

  const emitCountdownVisible = () => {
    const phone = readPhone();
    if (!phone) {
      lastCountdownVisible = false;
      return;
    }

    const candidates = Array.from(document.querySelectorAll(COUNTDOWN_SELECTOR));
    const el = candidates.find(isVisible);
    const raw = (el && (el.textContent || el.innerText || el.value || '') || '').toString().trim();
    const text = raw.replace(/\s+/g, ' ');
    const title = String(el && el.getAttribute && el.getAttribute('title') || '');
    const phoneKey = normalizePhoneKey(phone);

    // Accept 60,59,58... and also values that include a trailing 's' (for example 60s).
    const m = text.match(/^(?:([1-9])|([1-5]\d)|60)\s*(?:s|sec|secs|second|seconds)?$/i) || title.match(/^(?:([1-9])|([1-5]\d)|60)\s*(?:s|sec|secs|second|seconds)?$/i);
    const looksLikeCountdown = !!el && !!m;

    if (!phoneKey) {
      lastCountdownVisible = false;
      return;
    }

    if (!looksLikeCountdown) {
      lastCountdownVisible = false;
      lastCountdownPhoneKey = phoneKey;
      return;
    }

    const justAppeared = !lastCountdownVisible || lastCountdownPhoneKey !== phoneKey;
    lastCountdownVisible = true;
    lastCountdownPhoneKey = phoneKey;

    if (!justAppeared) return;
    if (lastCountdownEmittedPhoneKey === phoneKey) return;

    lastCountdownEmittedPhoneKey = phoneKey;
    post("COUNTDOWN_VISIBLE", { phone, at: Date.now(), text });
  };

  const clickConfirmButtonIfVisible = () => {
    const phone = readPhone() || lastPhone;
    const phoneKey = normalizePhoneKey(phone);
    if (!phoneKey) return false;

    const candidates = Array.from(document.querySelectorAll(CONFIRM_SELECTOR));
    const el = candidates.find((node) => isVisible(node));
    if (!el) {
      if (lastConfirmClickedPhoneKey === phoneKey) {
        lastConfirmClickedPhoneKey = "";
      }
      return false;
    }

    const text = (el && (el.textContent || el.innerText || el.value || '') || '').toString().trim();
    const title = String(el && el.getAttribute && el.getAttribute('title') || '');
    const looksLikeConfirm = /\bconfirm\b/i.test(text) || /\bconfirm\b/i.test(title);
    if (!looksLikeConfirm) return false;

    try {
      if (typeof el.click === 'function') {
        el.click();
      } else {
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
      }

      // Do not lock out future retries until the UI actually changes.
      // If the first attempt happens too early, the next 20ms tick can try again.
      const stillVisible = Array.from(document.querySelectorAll(CONFIRM_SELECTOR)).some((node) => isVisible(node));
      if (stillVisible) {
        lastConfirmClickedPhoneKey = "";
      } else {
        lastConfirmClickedPhoneKey = phoneKey;
      }

      post("CONFIRM_AUTO_CLICKED", { phone, at: Date.now(), text });
      post("CONFIRM", { phone, at: Date.now(), text, source: "auto_click" });
      lastPhone = phone || lastPhone;
      return true;
    } catch {
      return false;
    }
  };

  const emitConfirm = () => {
    const phone = readPhone();
    post("CONFIRM", { phone, at: Date.now() });
  };

  const looksRelevant = (text) => {
    if (!text) return false;
    return /(\[wrapup\])|countdown tick|call ended|ending call|\bBYE\b|\bCANCEL\b|\bINVITE\b|\b200 OK\b|wrapup/i.test(text);
  };

  const extractEventId = (text) => {
    const s = String(text || "");
    const m1 = s.match(/\[wrapup\]\[(\d+)\]/i);
    if (m1) return `wrapup:${m1[1]}`;
    const m2 = s.match(/countdown tick:\s*(\d+)/i);
    if (m2) return `tick:${m2[1]}`;
    const m3 = s.match(/Call-ID:\s*([A-Za-z0-9._-]+)/i);
    if (m3) return `callid:${m3[1]}`;
    return "";
  };

  post("READY", { url: location.href });

  const handleClick = (ev) => {
    try {
      const btn = ev.target && ev.target.closest ? ev.target.closest(CONFIRM_SELECTOR) : null;
      if (!btn) return;
      emitConfirm();
    } catch {}
  };

  document.addEventListener("click", handleClick, true);
  document.addEventListener("submit", (ev) => {
    try {
      const btn = ev.submitter;
      const confirm = btn && btn.matches ? btn.matches(CONFIRM_SELECTOR) : false;
      if (confirm) emitConfirm();
    } catch {}
  }, true);

  try {
    const nativeLog = console.log.bind(console);
    console.log = (...args) => {
      try {
        const text = args
          .map((a) => {
            if (typeof a === "string") return a;
            if (a instanceof Error) return a.stack || a.message || String(a);
            try { return JSON.stringify(a); } catch { return String(a); }
          })
          .join(" ");
        if (looksRelevant(text)) {
          post("CONSOLE", { text, eventId: extractEventId(text) });
        }
      } catch {}
      return nativeLog(...args);
    };
  } catch {}

  try {
    const NativeWebSocket = window.WebSocket;
    if (NativeWebSocket && !NativeWebSocket.__tokuCallLogPatched) {
      const PatchedWebSocket = new Proxy(NativeWebSocket, {
        construct(target, args, newTarget) {
          const ws = Reflect.construct(target, args, newTarget);
          let url = "";
          try { url = String(args[0] || ws.url || ""); } catch {}
          post("WS_OPEN", { url });

          try {
            ws.addEventListener("message", (ev) => {
              try {
                const data = typeof ev.data === "string" ? ev.data : "";
                if (looksRelevant(data)) {
                  post("WS_MESSAGE", { url, data, eventId: extractEventId(data) });
                }
              } catch {}
            });
          } catch {}

          return ws;
        },
      });
      PatchedWebSocket.__tokuCallLogPatched = true;
      window.WebSocket = PatchedWebSocket;
    }
  } catch {}

  try {
    const obs = new MutationObserver(() => {
      emitPhone();
      emitWrapUpVisible();
      emitCountdownVisible();
      emitConfirmVisible();
      clickConfirmButtonIfVisible();
    });
    obs.observe(document.documentElement, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
    });
  } catch {}

  setInterval(() => {
    emitPhone();
    emitWrapUpVisible();
    emitCountdownVisible();
    emitConfirmVisible();
    clickConfirmButtonIfVisible();
  }, 20);

  emitPhone();
  emitWrapUpVisible();
})();