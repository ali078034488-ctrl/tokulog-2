chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== "OPEN_OPTIONS") return;

  const open = async () => {
    try {
      if (chrome.runtime.openOptionsPage) {
        await chrome.runtime.openOptionsPage();
        sendResponse({ ok: true, method: "openOptionsPage" });
        return;
      }
    } catch {}

    try {
      const url = chrome.runtime.getURL("options.html");
      await chrome.tabs.create({ url });
      sendResponse({ ok: true, method: "tabs.create" });
      return;
    } catch (err) {
      sendResponse({ ok: false, error: String(err) });
    }
  };

  open();
  return true;
});
