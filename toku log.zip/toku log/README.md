# Toku Call Log

## Fix in this version
- Strong dedupe for the same call/session using a normalized phone key, wrapup IDs, call IDs, and a longer per-phone lock
- Floating launcher stays at the bottom-left
- Small vertical panel
- Clear Log in the top bar
- Search removed
- Countdown in seconds
- Expiry tone in settings


## Settings button
- The settings button now opens the options page through a background service worker for better reliability.


- Fixed a crash in the dedupe state so phone capture works again.

- Capture the phone number fresh from the DOM at Wrap Up/end-of-call time so the countdown starts from the true call end.

- Clear Log and Delete now fully reset the extension state and stored data.
- Clear Log keeps the floating window open instead of hiding it.


Version 2.2.2 adds a small restore button beside Clear Log to recover the last cleared numbers.


Version 2.2.3 adds a visible three-row grid with cell dividers. Empty placeholder rows remain at three until a fourth call entry is added, then rows grow with the log.


Restore behavior: the Restore button restores one deleted entry per click, in the order they were queued, including after Clear Log.


Version 2.2.9 restores each deleted number to its original table order, including after Clear Log or consecutive Delete actions.


Version 2.3.0 adds left-click drag-and-drop row reordering.
