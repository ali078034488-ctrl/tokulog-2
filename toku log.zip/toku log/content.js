(() => {
  const STORAGE_KEYS = {
    entries: "tokuCallLogEntries",
    lastClearedEntries: "tokuCallLogLastClearedEntries",
    lastRestoreMode: "tokuCallLogLastRestoreMode",
    settings: "tokuCallLogSettings",
    uiState: "tokuCallLogUiState",
  };

  const DEFAULT_SETTINGS = {
    defaultSeconds: 180,
    soundEnabled: true,
    panelWidth: 520,
    panelHeight: 380,
    autoWidth: false,
    rowPadding: 10,
    columnPadding: 12,
    preventConsecutiveDuplicates: false,
  };

  const PHONE_FONT = '700 13.5px ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace';
  const AUTO_WIDTH_MIN = 420;
  const AUTO_WIDTH_MAX = 860;
  const AUTO_WIDTH_OTHER_COLUMNS = 300;
  let measureCanvas = null;

  const measureTextWidth = (text, font) => {
    if (!measureCanvas) measureCanvas = document.createElement("canvas");
    const ctx = measureCanvas.getContext("2d");
    ctx.font = font;
    return ctx.measureText((text || "").toString()).width;
  };

  const computeAutoWidth = () => {
    let maxPhoneWidth = 0;
    for (const entry of state.entries) {
      const w = measureTextWidth(entry && entry.phone, PHONE_FONT);
      if (w > maxPhoneWidth) maxPhoneWidth = w;
    }
    if (!maxPhoneWidth) return DEFAULT_SETTINGS.panelWidth;
    const target = Math.ceil(maxPhoneWidth) + AUTO_WIDTH_OTHER_COLUMNS;
    return Math.min(AUTO_WIDTH_MAX, Math.max(AUTO_WIDTH_MIN, target));
  };

  const clampSize = (value, fallback) => {
    const n = parseInt(value, 10);
    if (!Number.isFinite(n) || n <= 0) return fallback;
    return n;
  };

  const EVENT_WINDOW_MS = 1500;

  const SELECTORS = {
    phone: 'p[data-testid="Base-Dialer-Keypad-Number-Flex-Text-0"]',
    confirmBtn: '#toku-omnichannel--wrapUp-confirmButton',
  };

  const state = {
    entries: [],
    lastClearedEntries: [],
    lastRestoreMode: "clear",
    settings: { ...DEFAULT_SETTINGS },
    ui: null,
    hidden: true,
    timer: null,
    drag: { active: false, offsetX: 0, offsetY: 0 },
    currentPhone: "",
    lastEventAt: 0,
    lastEventKey: "",
    seenEventIds: {},
    lastLoggedPhoneKey: "",
    startConsumedPhoneKey: "",
    startWinnerSource: "",
    lastConfirmAt: 0,
    startLockExpiresAt: 0,
    lastConfirmVisibleAt: 0,
    lastWrapUpVisibleAt: 0,
    lastCallSignalAt: 0,
    pendingStartTimeout: null,
    pendingStartPhoneKey: "",
    pendingStartSource: "",
    hookTimer: null,
    audioCtx: null,
    audioUnlocked: false,
    bootAt: Date.now(),
  };

  const pad = (n) => String(n).padStart(2, "0");
  const digitsOnly = (value) => (value || "").toString().replace(/[^\d+]/g, "").trim();

  const normalizePhoneKey = (value) => {
    const digits = (value || "").toString().replace(/\D/g, "");
    if (!digits) return "";
    if (digits.startsWith("964") && digits.length > 9) return digits.slice(3).replace(/^0+/, "");
    return digits.replace(/^0+/, "");
  };

  const formatClock = (ms) => {
    const d = new Date(ms);
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };

  const formatDuration = (minutes) => `${pad(minutes)}:00`;

  const formatRemaining = (expiresAt) => {
    const remainingMs = Math.max(0, expiresAt - Date.now());
    const totalSec = Math.floor(remainingMs / 1000);
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${pad(m)}:${pad(s)}`;
  };

  const isExpired = (expiresAt) => Date.now() >= expiresAt;

  const safeId = () => {
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    return `id_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  };

  const readPhoneFromDom = () => {
    const el = document.querySelector(SELECTORS.phone);
    if (!el) return "";
    return digitsOnly(el.textContent || el.innerText || "");
  };

  const ensurePhone = () => state.currentPhone || readPhoneFromDom();

  const markCallSignal = () => {
    state.lastCallSignalAt = Date.now();
  };

  const isCallLikelyActive = () => {
    const phone = digitsOnly(readPhoneFromDom() || state.currentPhone);
    if (phone) return true;
    return Date.now() - (state.lastCallSignalAt || 0) < 5000;
  };

  const loadStorage = () => new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEYS.entries, STORAGE_KEYS.lastClearedEntries, STORAGE_KEYS.lastRestoreMode, STORAGE_KEYS.settings, STORAGE_KEYS.uiState], (data) => resolve(data || {}));
  });

  const saveStorage = () => new Promise((resolve) => {
    chrome.storage.local.set(
      {
        [STORAGE_KEYS.entries]: state.entries,
        [STORAGE_KEYS.lastClearedEntries]: state.lastClearedEntries,
        [STORAGE_KEYS.lastRestoreMode]: state.lastRestoreMode,
        [STORAGE_KEYS.uiState]: {
          hidden: state.hidden,
          left: state.ui ? state.ui.getElementById("panel")?.style.left : undefined,
          top: state.ui ? state.ui.getElementById("panel")?.style.top : undefined,
        },
      },
      () => resolve()
    );
  });

  const dedupeEntries = (entries = []) => {
    const seen = new Set();
    const result = [];
    for (const entry of Array.isArray(entries) ? entries : []) {
      if (!entry || typeof entry !== "object") continue;
      const key = [
        normalizePhoneKey(entry.phone),
        entry.endTime || "",
        entry.expiresAt || "",
        entry.id || "",
      ].join("|");
      if (!key.replace(/\|/g, "")) continue;
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(entry);
    }
    return result;
  };

  // Keep the table in its original newest-to-oldest order when an entry is restored.
  // Each call entry already has an endTime, so restoring can place it back between
  // the same neighbouring calls without disturbing newer entries.
  const sortEntriesByOriginalOrder = (entries = []) => {
    return [...entries].sort((a, b) => {
      const aTime = Number(a?.endTime || a?.startTime || 0);
      const bTime = Number(b?.endTime || b?.startTime || 0);
      if (aTime !== bTime) return bTime - aTime;

      const aOrder = Number(a?._restoreOrder ?? Number.MAX_SAFE_INTEGER);
      const bOrder = Number(b?._restoreOrder ?? Number.MAX_SAFE_INTEGER);
      if (aOrder !== bOrder) return aOrder - bOrder;

      return String(a?.id || "").localeCompare(String(b?.id || ""));
    });
  };

  const resetRuntimeState = () => {
    state.entries = [];
    state.settings = { ...DEFAULT_SETTINGS };
    state.currentPhone = "";
    state.lastEventAt = 0;
    state.lastEventKey = "";
    state.seenEventIds = {};
    state.lastLoggedPhoneKey = "";
    state.startConsumedPhoneKey = "";
    state.startLockExpiresAt = 0;
    state.lastConfirmAt = 0;
    state.lastConfirmVisibleAt = 0;
    state.lastWrapUpVisibleAt = 0;
    if (state.pendingStartTimeout) clearTimeout(state.pendingStartTimeout);
    state.pendingStartTimeout = null;
    state.pendingStartPhoneKey = "";
    state.pendingStartSource = "";
  };

  const updateRestoreButton = () => {
    if (!state.ui) return;
    const restoreBtn = state.ui.getElementById("restore");
    if (!restoreBtn) return;
    const hasEntries = Array.isArray(state.lastClearedEntries) && state.lastClearedEntries.length > 0;
    restoreBtn.disabled = !hasEntries;
    restoreBtn.title = hasEntries ? `Restore next deleted number (${state.lastClearedEntries.length} remaining)` : "Nothing to restore";
  };

  const clearAllData = async () => {
    if (state.entries.length) {
      state.lastClearedEntries = state.entries.map((entry) => ({ ...entry }));
      state.lastRestoreMode = "clear";
    }
    state.entries = [];
    await new Promise((resolve) => {
      try {
        chrome.storage.local.set(
          {
            [STORAGE_KEYS.entries]: [],
            [STORAGE_KEYS.lastClearedEntries]: state.lastClearedEntries,
            [STORAGE_KEYS.lastRestoreMode]: state.lastRestoreMode,
          },
          () => resolve()
        );
      } catch {
        resolve();
      }
    });
    updateRestoreButton();
    render();
  };

  const restoreLastCleared = async () => {
    if (!Array.isArray(state.lastClearedEntries) || !state.lastClearedEntries.length) return;

    // Restore one queued entry per click, then put it back into its original
    // position instead of always placing it at the top of the table.
    const restoredEntry = { ...state.lastClearedEntries[0] };
    state.lastClearedEntries = state.lastClearedEntries.slice(1);
    state.entries = sortEntriesByOriginalOrder(dedupeEntries([...state.entries, restoredEntry]));

    state.lastLoggedPhoneKey = normalizePhoneKey(state.entries[0] && state.entries[0].phoneKey ? state.entries[0].phoneKey : "");

    await new Promise((resolve) => {
      try {
        chrome.storage.local.set(
          {
            [STORAGE_KEYS.entries]: state.entries,
            [STORAGE_KEYS.lastClearedEntries]: state.lastClearedEntries,
            [STORAGE_KEYS.lastRestoreMode]: state.lastRestoreMode,
          },
          () => resolve()
        );
      } catch {
        resolve();
      }
    });

    render({ scrollToTop: true });
    updateRestoreButton();
  };

  const unlockAudio = () => {
    if (state.audioUnlocked) return;
    try {
      const Ctor = window.AudioContext || window.webkitAudioContext;
      if (!Ctor) return;
      state.audioCtx = state.audioCtx || new Ctor();
      if (state.audioCtx.state === "suspended") {
        state.audioCtx.resume().catch(() => {});
      }
      state.audioUnlocked = true;
    } catch {}
  };

  const playShortTone = async () => {
    if (!state.settings.soundEnabled) return;
    unlockAudio();
    try {
      if (!state.audioCtx) return;
      if (state.audioCtx.state === "suspended") {
        await state.audioCtx.resume().catch(() => {});
      }
      const ctx = state.audioCtx;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = 880;
      gain.gain.value = 0.0001;

      osc.connect(gain);
      gain.connect(ctx.destination);

      const now = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.18, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);

      osc.start(now);
      osc.stop(now + 0.17);
    } catch {}
  };

  const beginCountdownOnce = async (phone, eventLabel = "wrapup") => {
    const cleaned = digitsOnly(phone);
    const phoneKey = normalizePhoneKey(phone);
    if (!cleaned || !phoneKey) return;

    const now = Date.now();
    const key = `${phoneKey}:${eventLabel}`;
    if (state.lastEventKey === key && now - state.lastEventAt < EVENT_WINDOW_MS) return;

    // Race logic: the first condition that fires wins for this phone/call.
    // After one condition wins, the other condition is ignored until a new phone appears.
    if (state.startConsumedPhoneKey === phoneKey) return;

    // Keep a short per-call lock so Confirm and Wrap Up cannot both create the same entry.
    if (isStartLockedForPhone(phoneKey)) return;

    // Prevent only consecutive duplicates, based on the most recent saved entry.
    if (state.settings.preventConsecutiveDuplicates === true) {
      const lastEntryPhoneKey = normalizePhoneKey(state.entries[0] && state.entries[0].phoneKey ? state.entries[0].phoneKey : "");
      const runtimeLastPhoneKey = state.lastLoggedPhoneKey || "";
      if (lastEntryPhoneKey === phoneKey || runtimeLastPhoneKey === phoneKey) return;
    }

    state.lastEventKey = key;
    state.lastEventAt = now;
    state.lastLoggedPhoneKey = phoneKey;
    lockStartForPhone(phoneKey);
    state.startWinnerSource = eventLabel;
    state.seenEventIds[eventLabel] = true;

    const seconds = Math.max(
      1,
      parseInt(state.settings.defaultSeconds || DEFAULT_SETTINGS.defaultSeconds, 10) || DEFAULT_SETTINGS.defaultSeconds
    );

    state.entries.unshift({
      id: safeId(),
      phone: cleaned,
      phoneKey,
      endTime: now,
      expiresAt: now + seconds * 1000,
      alerted: false,
    });

    state.entries = dedupeEntries(state.entries);

    await saveStorage();
    render({ scrollToTop: true });
  };


  const clearPendingStart = () => {
    if (state.pendingStartTimeout) clearTimeout(state.pendingStartTimeout);
    state.pendingStartTimeout = null;
    state.pendingStartPhoneKey = "";
    state.pendingStartSource = "";
  };

  const releaseStartLockIfExpired = () => {
    if (state.startLockExpiresAt && Date.now() >= state.startLockExpiresAt) {
      state.startConsumedPhoneKey = "";
      state.startLockExpiresAt = 0;
    }
  };

  const lockStartForPhone = (phoneKey, durationMs = 1800) => {
    state.startConsumedPhoneKey = phoneKey;
    state.startLockExpiresAt = Date.now() + Math.max(250, durationMs);
  };

  const isStartLockedForPhone = (phoneKey) => {
    releaseStartLockIfExpired();
    return !!phoneKey && state.startConsumedPhoneKey === phoneKey && state.startLockExpiresAt > Date.now();
  };

  const queueStartFromWrapUp = (phone) => {
    const cleaned = digitsOnly(phone);
    const phoneKey = normalizePhoneKey(phone);
    if (!cleaned || !phoneKey) return;

    if (isStartLockedForPhone(phoneKey)) return;
    if (state.pendingStartTimeout) clearTimeout(state.pendingStartTimeout);

    state.pendingStartPhoneKey = phoneKey;
    state.pendingStartSource = "wrapup";
    state.pendingStartTimeout = setTimeout(() => {
      try {
        if (state.pendingStartPhoneKey !== phoneKey || state.pendingStartSource !== "wrapup") return;
        beginCountdownOnce(phone, "wrapup");
      } finally {
        clearPendingStart();
      }
    }, 180);
  };

  const injectPageHook = () => {
    if (window.__TOKU_CALL_LOG_CONTENT_INJECTED__) return;
    window.__TOKU_CALL_LOG_CONTENT_INJECTED__ = true;

    const existing = document.getElementById("toku-call-log-page-hook");
    if (existing) return;

    const script = document.createElement("script");
    script.id = "toku-call-log-page-hook";
    script.src = chrome.runtime.getURL("page_hook.js");
    script.async = false;
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
  };

  const shouldRenderUi = () => {
    try {
      return window.top === window;
    } catch {
      return true;
    }
  };

  const ensureUi = () => {
    if (state.ui) return;
    if (!shouldRenderUi()) return;

    const host = document.createElement("div");
    host.id = "toku-call-log-host";
    host.style.position = "fixed";
    host.style.inset = "0";
    host.style.pointerEvents = "none";
    host.style.zIndex = "2147483647";
    document.documentElement.appendChild(host);

    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host, * { box-sizing: border-box; }

      #launcher {
        position: fixed;
        left: 18px;
        bottom: 18px;
        pointer-events: auto;
        border: 1px solid rgba(232,230,223,0.14);
        border-radius: 8px;
        background: #1b1c22;
        color: #e8e6df;
        box-shadow: 0 6px 18px rgba(0,0,0,0.35);
        font: 700 12px/1 ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace;
        cursor: pointer;
        padding: 11px 16px 11px 13px;
        display: inline-flex;
        align-items: center;
        gap: 9px;
        letter-spacing: 0.6px;
        text-transform: uppercase;
      }
      #launcher::before {
        content: "";
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #d98c2b;
        box-shadow: 0 0 0 3px rgba(217,140,43,0.20);
        flex: 0 0 auto;
      }
      #launcher:hover { background: #222329; border-color: rgba(232,230,223,0.22); }

      #panel {
        position: fixed;
        top: 24px;
        left: 24px;
        width: 520px;
        max-width: calc(100vw - 32px);
        background: #1b1c22;
        color: #e8e6df;
        border: 1px solid rgba(232,230,223,0.12);
        border-radius: 10px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.45);
        overflow: hidden;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
        display: none;
        pointer-events: auto;
      }
      #panel * { box-sizing: border-box; }

      #header {
        cursor: move;
        user-select: none;
        padding: 13px 16px;
        background: #202127;
        border-bottom: 2px solid #d98c2b;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
      #brand {
        display: flex;
        align-items: center;
        gap: 11px;
        min-width: 0;
      }
      #brand-mark {
        width: 34px;
        height: 34px;
        border-radius: 7px;
        overflow: hidden;
        border: 1px solid rgba(232,230,223,0.14);
        display: grid;
        place-items: center;
        flex: 0 0 auto;
        background: #16171c;
      }
      #brand-mark img {
        width: 100%;
        height: 100%;
        display: block;
        object-fit: cover;
      }
      #header-actions {
        display: flex;
        gap: 7px;
        flex: 0 0 auto;
        align-items: center;
      }
      .ghost {
        border: 1px solid rgba(232,230,223,0.14);
        background: transparent;
        color: #c7c7cf;
        border-radius: 7px;
        padding: 8px 12px;
        cursor: pointer;
        font-size: 11.5px;
        font-weight: 600;
        white-space: nowrap;
        transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
      }
      .ghost:hover {
        background: rgba(232,230,223,0.06);
        border-color: rgba(232,230,223,0.24);
        color: #e8e6df;
      }
      .ghost.danger {
        color: #d98577;
        border-color: rgba(179,80,63,0.35);
      }
      .ghost.danger:hover {
        background: rgba(179,80,63,0.14);
        border-color: rgba(179,80,63,0.5);
        color: #e8a99c;
      }
      .restore-btn {
        width: 30px;
        height: 30px;
        padding: 0;
        display: grid;
        place-items: center;
        border-radius: 7px;
        font-size: 15px;
        line-height: 1;
      }
      .restore-btn:disabled {
        opacity: 0.34;
        cursor: default;
      }
      .restore-btn:not(:disabled) {
        color: #d8b579;
        border-color: rgba(217,140,43,0.30);
      }
      .restore-btn:not(:disabled):hover {
        background: rgba(217,140,43,0.10);
        border-color: rgba(217,140,43,0.46);
        color: #ebc98f;
      }
      .row-delete {
        border: 1px solid rgba(179,80,63,0.35);
        background: transparent;
        color: #d98577;
        border-radius: 6px;
        padding: 5px 9px;
        cursor: pointer;
        font-size: 10.5px;
        font-weight: 600;
        white-space: nowrap;
        transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
      }
      .row-delete:hover {
        background: rgba(179,80,63,0.14);
        border-color: rgba(179,80,63,0.5);
        color: #e8a99c;
      }
      #body {
        padding: 14px 16px 15px;
        display: grid;
        gap: 11px;
      }
      #table-wrap {
        max-height: 380px;
        overflow: auto;
        border: 1px solid rgba(232,230,223,0.08);
        border-radius: 4px;
        background: #17181d;
      }
      table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        font-size: 12px;
        table-layout: fixed;
      }
      thead th {
        position: sticky;
        top: 0;
        text-align: left;
        padding: calc(var(--toku-row-padding, 10px) * 0.8) var(--toku-column-padding, 12px);
        white-space: nowrap;
        color: #8b8c96;
        font-size: 10px;
        text-transform: uppercase;
        letter-spacing: 0.7px;
        font-weight: 700;
        background: #202127;
        border-bottom: 1px solid rgba(232,230,223,0.10);
      }
      th,
      td {
        border-right: 1px solid rgba(232,230,223,0.10);
      }
      th:last-child,
      td:last-child {
        border-right: none;
      }
      tbody td {
        padding: var(--toku-row-padding, 10px) var(--toku-column-padding, 12px);
        vertical-align: middle;
        border-bottom: 1px solid rgba(232,230,223,0.10);
      }
      tbody tr:first-child td {
        border-top: 1px solid rgba(232,230,223,0.10);
      }
      tbody tr.row-even td { background: rgba(232,230,223,0.02); }
      tbody tr.row-placeholder td {
        height: 42px;
        background: rgba(255,255,255,0.008);
      }
      tbody tr.row-active { box-shadow: inset 3px 0 0 #d98c2b; }
      tbody tr.row-expired { box-shadow: inset 3px 0 0 #b3503f; }
      tbody tr.row-draggable { cursor: grab; }
      tbody tr.row-draggable:active { cursor: grabbing; }
      tbody tr.row-dragging { opacity: 0.55; }
      tbody tr.row-drag-over td { box-shadow: inset 0 2px 0 rgba(217,140,43,0.85); }
      tbody tr:hover td { background: rgba(232,230,223,0.045); }
      tbody tr:last-child td { border-bottom: none; }
      .phone {
        font-family: ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace;
        font-weight: 700;
        font-size: 13.5px;
        letter-spacing: 0.4px;
        color: #e8e6df;
      }
      .meta {
        font-size: 10.5px;
        color: #71717a;
        margin-top: 3px;
        font-family: ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace;
      }
      .ended-badge {
        display: inline-block;
        color: #9b9ba3;
        font-family: ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace;
        font-weight: 600;
        font-size: 11.5px;
        letter-spacing: 0.2px;
      }
      .timer-badge {
        display: inline-block;
        font-family: ui-monospace, SFMono-Regular, "SF Mono", Consolas, "Liberation Mono", monospace;
        font-weight: 700;
        font-size: 13px;
        letter-spacing: 0.4px;
        border-radius: 5px;
        padding: 4px 9px;
        border: 1px solid transparent;
        vertical-align: middle;
      }
      .timer-active { color: #d98c2b; background: rgba(217,140,43,0.10); border-color: rgba(217,140,43,0.28); }
      .timer-expired { color: #d98577; background: rgba(179,80,63,0.12); border-color: rgba(179,80,63,0.32); }
      #empty {
        padding: 22px 12px;
        color: #71717a;
        text-align: center;
        font-size: 12px;
      }
      #credit {
        text-align: center;
        font-size: 10px;
        color: #55565f;
        padding-top: 2px;
        letter-spacing: 0.2px;
        width: fit-content;
        margin: 0 auto;
      }
    `;

    const launcher = document.createElement("button");

    launcher.id = "launcher";
    launcher.type = "button";
    launcher.textContent = "Call Log";

    const panel = document.createElement("div");
    panel.id = "panel";
    panel.innerHTML = `
      <div id="header">
        <div id="brand">
          <div id="brand-mark"><img id="brand-icon" alt="Call Log" /></div>
        </div>
        <div id="header-actions">
          <button id="settings" class="ghost" type="button">Settings</button>
          <button id="clear" class="ghost danger" type="button">Clear Log</button>
          <button id="restore" class="ghost restore-btn" type="button" aria-label="Restore last cleared numbers" title="Nothing to restore" disabled>↶</button>
          <button id="hide" class="ghost" type="button">Hide</button>
        </div>
      </div>

      <div id="body">
        <div id="table-wrap">
          <table>
            <thead>
              <tr>
                <th style="width: 38%;">Phone</th>
                <th style="width: 22%;">Ended</th>
                <th style="width: 22%;">Timer</th>
                <th style="width: 18%;">Action</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
          <div id="empty" style="display:none;">No call log entries yet.</div>
        </div>

        <div id="credit">تم التطوير بواسطه المهندس عبدالرحمن الهاشمي</div>
      </div>
    `;

    const brandIcon = panel.querySelector("#brand-icon");
    if (brandIcon) {
      try {
        brandIcon.src = chrome.runtime.getURL("icon48.png");
      } catch {}
    }

    shadow.append(style, launcher, panel);
    state.ui = shadow;

    const header = panel.querySelector("#header");
    const hideBtn = panel.querySelector("#hide");
    const settingsBtn = panel.querySelector("#settings");
    const clearBtn = panel.querySelector("#clear");
    const restoreBtn = panel.querySelector("#restore");

    launcher.addEventListener("click", async () => {
      const isHidden = panel.style.display === "none" || !panel.style.display;
      panel.style.display = isHidden ? "block" : "none";
      state.hidden = !isHidden;
      await saveStorage();
    });

    hideBtn.addEventListener("click", async () => {
      panel.style.display = "none";
        await saveStorage();
    });

settingsBtn.addEventListener("click", () => {
  try {
    chrome.runtime.sendMessage({ type: "OPEN_OPTIONS" }, () => {
      void chrome.runtime.lastError;
    });
  } catch {
    try {
      if (chrome.runtime.openOptionsPage) chrome.runtime.openOptionsPage();
    } catch {}
  }
});

    clearBtn.addEventListener("click", async () => {
      await clearAllData();
    });

    restoreBtn.addEventListener("click", async () => {
      await restoreLastCleared();
    });

    header.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      state.drag.active = true;
      const rect = panel.getBoundingClientRect();
      state.drag.offsetX = e.clientX - rect.left;
      state.drag.offsetY = e.clientY - rect.top;
      document.addEventListener("mousemove", onDragMove);
      document.addEventListener("mouseup", onDragEnd, { once: true });
    });

    function onDragMove(e) {
      if (!state.drag.active) return;
      const maxX = window.innerWidth - panel.offsetWidth;
      const maxY = window.innerHeight - panel.offsetHeight;
      const left = Math.max(0, Math.min(maxX, e.clientX - state.drag.offsetX));
      const top = Math.max(0, Math.min(maxY, e.clientY - state.drag.offsetY));
      panel.style.left = `${left}px`;
      panel.style.top = `${top}px`;
      panel.style.right = "auto";
    }

    async function onDragEnd() {
      state.drag.active = false;
      document.removeEventListener("mousemove", onDragMove);
      await saveStorage();
    }

    panel.style.display = state.hidden ? "none" : "block";
  };

  const applyPanelSize = () => {
    if (!state.ui) return;
    const panel = state.ui.getElementById("panel");
    const tableWrap = state.ui.getElementById("table-wrap");
    const width = state.settings.autoWidth
      ? computeAutoWidth()
      : clampSize(state.settings.panelWidth, DEFAULT_SETTINGS.panelWidth);
    const height = clampSize(state.settings.panelHeight, DEFAULT_SETTINGS.panelHeight);
    if (panel) panel.style.width = `${width}px`;
    if (tableWrap) tableWrap.style.maxHeight = `${height}px`;
  };

  const applyTableSize = () => {
    if (!state.ui) return;
    const panel = state.ui.getElementById("panel");
    if (!panel) return;
    const rowPadding = Math.min(20, Math.max(2, parseInt(state.settings.rowPadding, 10) || DEFAULT_SETTINGS.rowPadding));
    const columnPadding = Math.min(24, Math.max(2, parseInt(state.settings.columnPadding, 10) || DEFAULT_SETTINGS.columnPadding));
    panel.style.setProperty("--toku-row-padding", `${rowPadding}px`);
    panel.style.setProperty("--toku-column-padding", `${columnPadding}px`);
  };

  const updateStats = () => {
    if (!state.ui) return;
  };

  const syncExpiredEntries = async () => {
    let changed = false;
    for (const entry of state.entries) {
      const expiredNow = isExpired(entry.expiresAt);
      if (expiredNow && !entry.alerted) {
        entry.alerted = true;
        changed = true;
        if (entry.expiresAt > state.bootAt) {
          playShortTone();
        }
      }
    }
    if (changed) {
      await saveStorage();
    }
  };

  let activeDragIndex = null;

  const moveEntry = async (fromIndex, toIndex) => {
    const from = Number(fromIndex);
    const to = Number(toIndex);
    if (!Number.isInteger(from) || !Number.isInteger(to)) return;
    if (from < 0 || from >= state.entries.length) return;

    const maxTarget = state.entries.length;
    const target = Math.max(0, Math.min(to, maxTarget));
    if (from === target || (target === maxTarget && from === maxTarget - 1)) {
      activeDragIndex = null;
      return;
    }

    const [movedEntry] = state.entries.splice(from, 1);
    let insertAt;
    if (target >= maxTarget) {
      insertAt = state.entries.length;
    } else if (from < target) {
      insertAt = target - 1;
    } else {
      insertAt = target;
    }
    insertAt = Math.max(0, Math.min(insertAt, state.entries.length));
    state.entries.splice(insertAt, 0, movedEntry);
    activeDragIndex = null;

    await saveStorage();
    render();
  };

  const render = ({ scrollToTop = false } = {}) => {
    if (!state.ui) return;
    const panel = state.ui.getElementById("panel");
    const tableWrap = state.ui.getElementById("table-wrap");
    const tbody = state.ui.querySelector("tbody");
    const empty = state.ui.getElementById("empty");

    applyPanelSize();
    applyTableSize();

    const filtered = state.entries;

    tbody.innerHTML = "";
    empty.style.display = "none";

    const minimumRows = 3;
    const rowCount = Math.max(minimumRows, filtered.length);
    let rowIndex = 0;

    for (let i = 0; i < rowCount; i++) {
      const entry = filtered[i] || null;
      const tr = document.createElement("tr");
      const isPlaceholder = !entry;
      tr.className = `row-${rowIndex % 2 === 0 ? "even" : "odd"}${entry ? ` ${isExpired(entry.expiresAt) ? "row-expired" : "row-active"} row-draggable` : " row-placeholder"}`;
      tr.dataset.dropIndex = String(i);

      if (isPlaceholder) {
        tr.innerHTML = `
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        `;

        tr.addEventListener("dragover", (e) => {
          if (activeDragIndex === null) return;
          e.preventDefault();
          e.dataTransfer.dropEffect = "move";
          tr.classList.add("row-drag-over");
        });
        tr.addEventListener("dragleave", () => tr.classList.remove("row-drag-over"));
        tr.addEventListener("drop", async (e) => {
          if (activeDragIndex === null) return;
          e.preventDefault();
          e.stopPropagation();
          tr.classList.remove("row-drag-over");
          await moveEntry(activeDragIndex, Math.min(i, state.entries.length));
        });

        tbody.appendChild(tr);
        rowIndex++;
        continue;
      }

      const remaining = formatRemaining(entry.expiresAt);
      const expired = isExpired(entry.expiresAt);
      const endedAt = entry.endTime || entry.startTime || Date.now();
      const entrySeconds = Math.max(0, Math.round((entry.expiresAt - endedAt) / 1000));
      const entryIndex = i;
      rowIndex++;
      tr.draggable = true;
      tr.title = "Drag with the left mouse button to move this row";

      tr.innerHTML = `
        <td>
          <div class="phone">${entry.phone || "-"}</div>
          <div class="meta">Timer ${pad(Math.floor(entrySeconds / 60))}:${pad(entrySeconds % 60)}</div>
        </td>
        <td><span class="ended-badge">${formatClock(entry.endTime || entry.startTime || Date.now())}</span></td>
        <td><span class="timer-badge ${expired ? "timer-expired" : "timer-active"}">${remaining}</span></td>
        <td><button type="button" class="row-delete" data-entry-index="${entryIndex}">Delete</button></td>
      `;

      tbody.appendChild(tr);

      tr.addEventListener("dragstart", (e) => {
        if (e.target.closest(".row-delete")) {
          e.preventDefault();
          return;
        }
        activeDragIndex = entryIndex;
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", String(entryIndex));
        tr.classList.add("row-dragging");
      });

      tr.addEventListener("dragover", (e) => {
        if (activeDragIndex === null || activeDragIndex === entryIndex) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        tr.classList.add("row-drag-over");
      });

      tr.addEventListener("dragleave", () => tr.classList.remove("row-drag-over"));

      tr.addEventListener("drop", async (e) => {
        if (activeDragIndex === null) return;
        e.preventDefault();
        e.stopPropagation();
        tr.classList.remove("row-drag-over");
        await moveEntry(activeDragIndex, entryIndex);
      });

      tr.addEventListener("dragend", () => {
        tr.classList.remove("row-dragging");
        activeDragIndex = null;
        tbody.querySelectorAll(".row-drag-over").forEach((row) => row.classList.remove("row-drag-over"));
      });
    }

    updateStats();

    if (scrollToTop && tableWrap) {
      requestAnimationFrame(() => {
        tableWrap.scrollTop = 0;
      });
    }

    const deleteButtons = tbody.querySelectorAll(".row-delete");
    deleteButtons.forEach((btn) => {
      btn.addEventListener("click", async () => {
        const idx = parseInt(btn.dataset.entryIndex, 10);
        if (Number.isNaN(idx)) return;
        const removedEntry = state.entries.splice(idx, 1)[0];
        if (!removedEntry) return;

        // Keep all consecutive single-row deletions available for one Restore action.
        // Save the entry's original row position as a tie-breaker for entries created
        // at the exact same millisecond. The main order is still based on endTime.
        const removedWithRestoreOrder = {
          ...removedEntry,
          _restoreOrder: idx,
        };
        if (state.lastRestoreMode === "delete" && Array.isArray(state.lastClearedEntries)) {
          state.lastClearedEntries.push(removedWithRestoreOrder);
        } else {
          state.lastClearedEntries = [removedWithRestoreOrder];
        }
        state.lastRestoreMode = "delete";

        await saveStorage();
        render();
      });
    });

    if (panel) {
      panel.dataset.ready = "1";
    }
    updateRestoreButton();
  };

  const processEvent = async (type, payload = {}) => {
    if (type === "PHONE" && payload.phone) {
      markCallSignal();
      const phone = digitsOnly(payload.phone);
      if (phone && phone !== state.currentPhone) {
        state.startConsumedPhoneKey = "";
        state.startLockExpiresAt = 0;
        state.startWinnerSource = "";
        state.lastEventKey = "";
        state.lastEventAt = 0;
        clearPendingStart();
      }
      state.currentPhone = phone;
      return;
    }

    if (type === "WRAPUP_VISIBLE") {
      markCallSignal();
      const now = Date.now();
      if (now - state.lastWrapUpVisibleAt < EVENT_WINDOW_MS) return;
      state.lastWrapUpVisibleAt = now;

      // Keep watching, but do not start the timer here.
      // The timer starts only after the Confirm button is pressed.
      return;
    }

    if (type === "COUNTDOWN_VISIBLE") {
      markCallSignal();
      // Keep watching, but do not start the timer here.
      // The timer starts only after the Confirm button is pressed.
      return;
    }

    if (type === "CONFIRM_VISIBLE") {
      markCallSignal();
      const now = Date.now();
      if (now - state.lastConfirmVisibleAt < EVENT_WINDOW_MS) return;
      state.lastConfirmVisibleAt = now;
      return;
    }

    if (type === "CONFIRM_AUTO_CLICKED") {
      markCallSignal();
      const phone = digitsOnly(readPhoneFromDom() || payload.phone || ensurePhone());
      if (phone) {
        clearPendingStart();
      }
      return;
    }

    if (type === "CONFIRM") {
      markCallSignal();
      const now = Date.now();
      if (now - state.lastConfirmAt < EVENT_WINDOW_MS) return;
      state.lastConfirmAt = now;

      const phone = digitsOnly(readPhoneFromDom() || payload.phone || ensurePhone());
      if (phone) {
        clearPendingStart();
        await beginCountdownOnce(phone, "confirm");
      }
      return;
    }

    if (type === "CONSOLE" || type === "WS_MESSAGE") {
      const text = (payload.text || payload.data || "").toString();
      if (!text) return;
    }
  };

  const bindPageMessages = () => {
    window.addEventListener("message", (ev) => {
      const data = ev.data;
      if (!data || data.__TOKU_CALL_LOG__ !== true) return;

      if (data.type === "READY" || data.type === "PHONE") {
        ensureUi();
      }

      processEvent(data.type, data.payload || {}).catch(() => {});
    });
  };

  const bootstrap = async () => {
    injectPageHook();

    const data = await loadStorage();
    if (Array.isArray(data[STORAGE_KEYS.entries])) state.entries = dedupeEntries(data[STORAGE_KEYS.entries]);
    if (Array.isArray(data[STORAGE_KEYS.lastClearedEntries])) state.lastClearedEntries = dedupeEntries(data[STORAGE_KEYS.lastClearedEntries]);
    if (data[STORAGE_KEYS.lastRestoreMode] === "delete" || data[STORAGE_KEYS.lastRestoreMode] === "clear") {
      state.lastRestoreMode = data[STORAGE_KEYS.lastRestoreMode];
    }
    if (data[STORAGE_KEYS.settings] && typeof data[STORAGE_KEYS.settings] === "object") {
      state.settings = { ...state.settings, ...data[STORAGE_KEYS.settings] };
    }
    state.lastLoggedPhoneKey = normalizePhoneKey(state.entries[0] && state.entries[0].phoneKey ? state.entries[0].phoneKey : "");
    releaseStartLockIfExpired();
    if (data[STORAGE_KEYS.uiState] && typeof data[STORAGE_KEYS.uiState] === "object") {
      state.hidden = !!data[STORAGE_KEYS.uiState].hidden;
    }

    ensureUi();
    if (!state.ui) return;

    const panel = state.ui.getElementById("panel");
    if (data[STORAGE_KEYS.uiState] && data[STORAGE_KEYS.uiState].left && data[STORAGE_KEYS.uiState].top) {
      panel.style.left = data[STORAGE_KEYS.uiState].left;
      panel.style.top = data[STORAGE_KEYS.uiState].top;
      panel.style.right = "auto";
    }

    applyPanelSize();
    applyTableSize();
    render();

    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes[STORAGE_KEYS.settings]) return;
      const next = changes[STORAGE_KEYS.settings].newValue;
      if (next && typeof next === "object") {
        state.settings = { ...state.settings, ...next };
        applyPanelSize();
        render();
      }
    });

    if (state.timer) clearInterval(state.timer);
    state.timer = setInterval(async () => {
      unlockAudio();
      releaseStartLockIfExpired();
      await syncExpiredEntries();
      render();
    }, 1000);

    if (state.hookTimer) clearInterval(state.hookTimer);
    state.hookTimer = setInterval(() => {
      if (isCallLikelyActive()) injectPageHook();
    }, 20);

    const keepAlive = new MutationObserver(() => {
      if (window.top === window && !document.getElementById("toku-call-log-host")) {
        state.ui = null;
        ensureUi();
        render();
      }
      const domPhone = readPhoneFromDom();
      if (domPhone) state.currentPhone = domPhone;
    });

    keepAlive.observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      characterData: true,
    });

    bindPageMessages();

    const domPhone = readPhoneFromDom();
    if (domPhone) state.currentPhone = domPhone;

    document.addEventListener("pointerdown", unlockAudio, { capture: true });
    document.addEventListener("keydown", unlockAudio, { capture: true });
  };

  bootstrap().catch(() => {});
})();
