const STORAGE_KEY = "tokuCallLogSettings";
const DEFAULTS = {
  defaultSeconds: 180,
  soundEnabled: true,
  panelWidth: 520,
  panelHeight: 380,
  autoWidth: false,
  rowPadding: 10,
  columnPadding: 12,
};
const secondsInput = document.getElementById("seconds");
const soundInput = document.getElementById("sound");
const panelWidthInput = document.getElementById("panelWidth");
const panelHeightInput = document.getElementById("panelHeight");
const autoWidthInput = document.getElementById("autoWidth");
const rowPaddingInput = document.getElementById("rowPadding");
const columnPaddingInput = document.getElementById("columnPadding");
const saveTableSizeBtn = document.getElementById("saveTableSize");
const resetTableSizeBtn = document.getElementById("resetTableSize");
const preventConsecutiveDuplicatesInput = document.getElementById("preventConsecutiveDuplicates");
const saveBtn = document.getElementById("save");
const saveSizeBtn = document.getElementById("saveSize");
const resetSizeBtn = document.getElementById("resetSize");
const testBtn = document.getElementById("test");
const statusEl = document.getElementById("status");

function syncWidthInputState() {
  panelWidthInput.disabled = !!autoWidthInput.checked;
}

function clampSize(value, key) {
  const n = parseInt(value, 10);
  if (!Number.isFinite(n) || n <= 0) return DEFAULTS[key];
  return n;
}

function clampTableValue(value, min, max, fallback) {
  const n = parseInt(value, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

let audioCtx = null;

function setStatus(message) {
  statusEl.textContent = message;
  if (message) {
    setTimeout(() => {
      if (statusEl.textContent === message) statusEl.textContent = "";
    }, 1800);
  }
}

function loadSettings() {
  chrome.storage.local.get([STORAGE_KEY], (data) => {
    const settings = data[STORAGE_KEY] || {};
    secondsInput.value = String(Math.max(1, parseInt(settings.defaultSeconds || DEFAULTS.defaultSeconds, 10)));
    soundInput.checked = settings.soundEnabled !== false;
    panelWidthInput.value = String(clampSize(settings.panelWidth || DEFAULTS.panelWidth, "panelWidth"));
    panelHeightInput.value = String(clampSize(settings.panelHeight || DEFAULTS.panelHeight, "panelHeight"));
    autoWidthInput.checked = settings.autoWidth === true;
    rowPaddingInput.value = String(clampTableValue(settings.rowPadding ?? DEFAULTS.rowPadding, 2, 20, DEFAULTS.rowPadding));
    columnPaddingInput.value = String(clampTableValue(settings.columnPadding ?? DEFAULTS.columnPadding, 2, 24, DEFAULTS.columnPadding));
    preventConsecutiveDuplicatesInput.checked = settings.preventConsecutiveDuplicates === true;
    syncWidthInputState();
  });
}

function saveSettings(message = "Saved") {
  const seconds = Math.max(1, parseInt(secondsInput.value || DEFAULTS.defaultSeconds, 10) || DEFAULTS.defaultSeconds);
  const panelWidth = clampSize(panelWidthInput.value, "panelWidth");
  const panelHeight = clampSize(panelHeightInput.value, "panelHeight");
  const rowPadding = clampTableValue(rowPaddingInput.value, 2, 20, DEFAULTS.rowPadding);
  const columnPadding = clampTableValue(columnPaddingInput.value, 2, 24, DEFAULTS.columnPadding);
  panelWidthInput.value = String(panelWidth);
  panelHeightInput.value = String(panelHeight);
  rowPaddingInput.value = String(rowPadding);
  columnPaddingInput.value = String(columnPadding);
  chrome.storage.local.set(
    {
      [STORAGE_KEY]: {
        defaultSeconds: seconds,
        soundEnabled: !!soundInput.checked,
        panelWidth,
        panelHeight,
        autoWidth: !!autoWidthInput.checked,
        rowPadding,
        columnPadding,
        preventConsecutiveDuplicates: !!preventConsecutiveDuplicatesInput.checked,
      },
    },
    () => setStatus(message)
  );
}

function resetSize() {
  panelWidthInput.value = String(DEFAULTS.panelWidth);
  panelHeightInput.value = String(DEFAULTS.panelHeight);
  saveSettings("Size reset");
}

function resetTableSize() {
  rowPaddingInput.value = String(DEFAULTS.rowPadding);
  columnPaddingInput.value = String(DEFAULTS.columnPadding);
  saveSettings("Table size reset");
}

async function playTestTone() {
  try {
    const Ctor = window.AudioContext || window.webkitAudioContext;
    if (!Ctor) return;

    audioCtx = audioCtx || new Ctor();
    if (audioCtx.state === "suspended") {
      await audioCtx.resume().catch(() => {});
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.value = 0.0001;
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    const now = audioCtx.currentTime;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.18, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.16);

    osc.start(now);
    osc.stop(now + 0.17);
    setStatus("Playing test sound");
  } catch {
    setStatus("Audio not available");
  }
}

saveBtn.addEventListener("click", () => saveSettings());
secondsInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings();
});
soundInput.addEventListener("change", () => saveSettings());
saveSizeBtn.addEventListener("click", () => saveSettings("Size saved"));
resetSizeBtn.addEventListener("click", resetSize);
panelWidthInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings("Size saved");
});
panelHeightInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings("Size saved");
});
autoWidthInput.addEventListener("change", () => {
  syncWidthInputState();
  saveSettings("Size saved");
});
saveTableSizeBtn.addEventListener("click", () => saveSettings("Table size saved"));
resetTableSizeBtn.addEventListener("click", resetTableSize);
rowPaddingInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings("Table size saved");
});
columnPaddingInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") saveSettings("Table size saved");
});
testBtn.addEventListener("click", playTestTone);

loadSettings();
